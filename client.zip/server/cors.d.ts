declare const corsConfig: import("express").RequestHandler;
export default corsConfig;
