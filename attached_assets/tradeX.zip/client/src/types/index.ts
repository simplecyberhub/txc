// client/src/types/index.ts
export interface User {
  id: number;
  username: string;
  // other properties...
}