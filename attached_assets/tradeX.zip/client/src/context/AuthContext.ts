// client/src/context/AuthContext.ts
export interface AuthContextType {
  isAuthenticated: boolean;
  isAdmin: boolean;
  // other properties...
}