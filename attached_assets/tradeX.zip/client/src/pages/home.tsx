import React from "react";

const Home: React.FC = () => {
  return (
    <div>
      <h1>Welcome to TradeSphere</h1>
      <p>This is the home page.</p>
    </div>
  );
};

export default Home;